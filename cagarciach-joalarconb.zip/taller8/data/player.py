class Player():
    def __init__(self, symbol, color):
        self._symbol = symbol
        self._color = color

    def getSymbol(self):
        return self._symbol

    def getColor(self):
        return self._color

    def __str__(self):
        pass

