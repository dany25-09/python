from data.client import Client
from data.room import Room
from interface.user_interface import UI

if __name__ == '__main__':
    print("[APP]: Start Running ... ")
    app = UI()
    app.mainloop()