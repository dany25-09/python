BACKGROUND = "NavajoWhite4"
TEXT = "light cyan"
COMPONENT = "NavajoWhite3"
FONT = ("VERDANA", 16)


STYLE = {
    "font": FONT,
    "bg": COMPONENT,
    "fg": TEXT
}
