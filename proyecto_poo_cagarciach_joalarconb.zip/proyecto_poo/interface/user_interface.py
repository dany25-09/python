import tkinter as tk
from interface import style
from register import Register

class UI(tk.Tk):

    def __init__(self, **args):
        super().__init__(**args)
        self.title("Sistema Gestor DE Hoteles")
        self.minsize(800, 500)

        # frame principal
        frame_pr = tk.Frame( master = self)
        frame_pr.pack(
            side = tk.TOP,
            fill = tk.BOTH,
            expand = True,
        )
        frame_pr.configure(background = style.BACKGROUND, width = 200)

        frame_pr.grid_columnconfigure(0, weight = 1)
        frame_pr.grid_rowconfigure(0, weight = 1)


        # Creo un diccionario que me guarde las clases de frames
    #     self.frames = {}
    #     for F in (Register):
    #         frame = F(frame_pr, self)
    #         self.frames[F] = frame
    #         frame.grid(row=0, column=0, sticky=tk.NSEW)
    #     self.show_frame(Register)
    #
    # def show_frame(self, container):
    #     frame = self.frames[container]
    #     frame.tkraise()   #   Manda el frame al frente de todo



        #segundo frame
        # frame_2 = tk.Frame(master = self)
        # frame_2.pack(
        #     side = tk.RIGHT,
        #     fill = tk.BOTH,
        #     expand = True,
        # )
        # frame_2.configure(background = style.BACKGROUND, width = 800)

        # frame_2.grid_columnconfigure(1, weight = 1)
        # frame_2.grid_rowconfigure(0, weight = 1)





        # container = tk.Label(master = self,
        #                     text = "Sistema Gestor de Hoteles",
        #                     font = ("NORMAL", 30),
        #                     bg   = "orchid2",
        #                     fg = "DarkOliveGreen1",
        #                     width = 10,  # Ancho
        #                     height=10       # Alto
        #                     ).pack(fill=tk.BOTH)


