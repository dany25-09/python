BACKGROUND = "dodger blue"
TEXT = "Black"
COMPONENT = "old lace"
FONT = ("NORMAL", 16)


STYLE = {
    "font": FONT,
    "bg": COMPONENT,
    "fg": TEXT
}

# MODES = {
#     "NORMAL": "Normal",
#     "ATREVIDO": "Atrevido",
#     "TIRULNA": "Tirulina"
# }