from controller import Controller

if __name__ == '__main__':
    print("[APP]: Start Running ... ")
    app = Controller()
    app.mainloop()