class Room():
    def __init__(self, type, price):
        self._type   = type
        self._price  = price
        self._list_clients = []


#Encapsulamiento type
    @property
    def type(self):
        return self._type

    @type.setter
    def type(self, new_type):
        self._type = new_type


##Encapsulamiento price
    @property
    def price(self):
        return self._price

    @price.setter
    def price(self, new_price):
        pass



    def __str__(self):
        print(f"Tipo de habitación: {self.type} \n Precio de la habitación: {self._price}")



