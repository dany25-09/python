class Client():
    def __init__(self, id, name, age):
        self._id     = id
        self._name   = name
        self._age    = age


#Encapsulamiento id
    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, new_id):
        pass


#Encapsulamiento name
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, new_name):
        pass

    #Encapsulamiento age
    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, new_age):
        pass
